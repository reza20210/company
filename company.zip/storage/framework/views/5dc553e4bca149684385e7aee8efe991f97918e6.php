<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ایجاد درباره ما جدید</h3>
    <div class="row">
        <div class="col-md-10 offset-md-1">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::open(['action' => '\App\Http\Controllers\Admin\AdminAboutController@store', 'files' => true]); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'عنوان: (اجباری)')); ?>

                <?php echo e(Form::text('title', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('description', 'توضیحات: (اجباری)')); ?>

                <?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('first_photo_id', 'تصویر اول: (اجباری)')); ?>

                <?php echo e(Form::file('first_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('second_photo_id', 'تصویر دوم: (اجباری)')); ?>

                <?php echo e(Form::file('second_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('third_photo_id', 'تصویر سوم: (اجباری)')); ?>

                <?php echo e(Form::file('third_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('forth_photo_id', 'تصویر چهارم: (اجباری)')); ?>

                <?php echo e(Form::file('forth_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('fifth_photo_id', 'تصویر پنجم: (اجباری)')); ?>

                <?php echo e(Form::file('fifth_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('sixth_photo_id', 'تصویر ششم: (اجباری)')); ?>

                <?php echo e(Form::file('sixth_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('ذخیره', ['class' => 'btn btn-success']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/abouts/create.blade.php ENDPATH**/ ?>