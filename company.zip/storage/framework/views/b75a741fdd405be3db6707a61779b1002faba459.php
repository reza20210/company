<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ویرایش سوال و پاسخ</h3>
    <div class="row">
        <div class="col-md-9 offset-md-2">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::model($question ,['method' => 'PATCH' ,'action' => ['\App\Http\Controllers\Admin\AdminQuestionController@update', $question->id]]); ?>

            <div class="form-group">
                <?php echo e(Form::label('questionTitle', 'عنوان سوال: (اجباری)')); ?>

                <?php echo e(Form::text('questionTitle', $question->questionTitle, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('answer', 'پاسخ سوال: (اجباری)')); ?>

                <?php echo e(Form::textarea('answer', $question->answer, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('بروزرسانی', ['class' => 'btn btn-success col-md-3']);; ?>

            </div>
            <?php echo Form::close(); ?>

            <?php echo Form::open(['method' => 'DELETE' ,'action' => ['\App\Http\Controllers\Admin\AdminQuestionController@destroy', $question->id]]); ?>

            <div class="form-group">
                <?php echo Form::submit('حذف', ['class' => 'btn btn-danger col-md-3']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/questions/edit.blade.php ENDPATH**/ ?>