﻿

<?php $__env->startSection('content'); ?>

    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->

    <!-- Page Title -->
    <div class="page-title-area" style="background-image: url(<?php echo e($about->third_photo->path); ?>); ">
        <div class="title-shape">
            <img src="<?php echo e(asset('assets/img/title/title-bg-shape.png')); ?>" alt="Shape">
        </div>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-content">
                        <h2>بازخورد مشتریان</h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('default')); ?>">صفحه اصلی</a>
                            </li>
                            <li>
                                <i class='bx bx-chevron-left'></i>
                            </li>
                            <li>
                                <span>بازخورد مشتریان</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Testimonials -->
    <section class="testimonials-area five ptb-100">
        <div class="container">
            <div class="row">

                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-12">
                        <div class="testimonials-item">
                            <i class='bx bxs-quote-right icon'></i>
                            <p><?php echo e($customer->companyAgentComment); ?></p>
                            <img
                                src="<?php echo e($customer->companyAgentPhotoId ? $customer->companyAgentPhoto->path : "http://www.placehold.it/400"); ?>"
                                alt="Testimonials">
                            <h3><?php echo e($customer->companyAgentName); ?></h3>
                            <span><?php echo e($customer->companyAgentRole); ?></span>
                            <ul>
                                <li>
                                    <i class='bx bxs-star checked'></i>
                                </li>
                                <li>
                                    <i class='bx bxs-star checked'></i>
                                </li>
                                <li>
                                    <i class='bx bxs-star checked'></i>
                                </li>
                                <li>
                                    <i class='bx bxs-star checked'></i>
                                </li>
                                <li>
                                    <i class='bx bxs-star checked'></i>
                                </li>
                            </ul>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="col-md-12 text-md-center align-content-center">
                <?php echo e($customers->links('vendor.pagination.mpage')); ?>

            </div>

        </div>
    </section>
    <!-- End Testimonials -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/testimonials.blade.php ENDPATH**/ ?>