﻿

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->

    <!-- Page Title -->
    <div class="page-title-area" style="background-image: url(<?php echo e($about->third_photo->path); ?>); ">
        <div class="title-shape">
            <img src="<?php echo e(asset('assets/img/title/title-bg-shape.png')); ?>" alt="Shape">
        </div>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-content">
                        <h2>جزئیات خدمات</h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('default')); ?>">صفحه اصلی</a>
                            </li>
                            <li>
                                <i class='bx bx-chevron-left'></i>
                            </li>
                            <li>
                                <span>جزئیات خدمات</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Services Details -->
    <div class="service-details-area ptb-100">
        <div class="container">
            <div class="row">

                <div class="col-lg-12">
                    <div class="details-item">

                        <div class="details-img">
                            <h2><?php echo e($service->title); ?></h2>
                            <p><?php echo $service->description; ?></p>
                            <?php if($service->photos): ?>
                                <div class="row">
                                    <?php $__currentLoopData = $service->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-6 col-lg-6">
                                            <img
                                                src="<?php echo e($photo ? $photo->path : "http://www.placehold.it/900x300"); ?>"
                                                alt="Details">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Services Details -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/service-details.blade.php ENDPATH**/ ?>