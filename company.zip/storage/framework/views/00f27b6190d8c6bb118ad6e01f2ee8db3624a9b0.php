﻿

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->

    <!-- Page Title -->
    <div class="page-title-area title-bg-three">
        <div class="title-shape">
            <img src="<?php echo e(asset('assets/img/title/title-bg-shape.png')); ?>" alt="Shape">
        </div>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-content">
                        <h2>پروژه ها</h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('default')); ?>">صفحه اصلی</a>
                            </li>
                            <li>
                                <i class='bx bx-chevron-left'></i>
                            </li>
                            <li>
                                <span>پروژه ها</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Project Details -->
    <div class="project-details-area pt-100">
        <div class="container">

            <div class="details-img">
                <div class="row align-items-center">

                    <div class="col-lg-6">
                        <div class="img-left">
                            <img src="<?php echo e($project->photo ? $project->photo->path : "http://www.placehold.it/900x300"); ?>"
                                 alt="Details">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="content-right">
                            <ul>
                                <li>
                                    دسته بندی:
                                    <span><?php echo e($project->category->title); ?></span>
                                </li>
                                <li>
                                    کاربر:
                                    <span><?php echo e($project->user->name); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>

            <div class="details-handle">
                <h2><?php echo e($project->title); ?></h2>
                <p><?php echo $project->description; ?></p>
            </div>

        </div>
    </div>
    <!-- End Project Details -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/project-details.blade.php ENDPATH**/ ?>