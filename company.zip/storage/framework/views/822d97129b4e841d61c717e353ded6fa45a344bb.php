<!DOCTYPE html>
<html lang="en" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Roxo Administrator">
    <meta name="author" content="Masoud Salehi">
    <meta name="keyword" content="Bootstrap Data">
    <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->
    <title>صفحه مدیریت</title>
    <!-- Icons -->
    <link href="<?php echo e(asset('css/all-admin.css')); ?>" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.7/js/tether.min.js"></script>

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<!-- BODY options, add following classes to body to change options
		1. 'compact-nav'     	  - Switch sidebar to minified version (width 50px)
		2. 'sidebar-nav'		  - Navigation on the left
			2.1. 'sidebar-off-canvas'	- Off-Canvas
				2.1.1 'sidebar-off-canvas-push'	- Off-Canvas which move content
				2.1.2 'sidebar-off-canvas-with-shadow'	- Add shadow to body elements
		3. 'fixed-nav'			  - Fixed navigation
		4. 'navbar-fixed'		  - Fixed navbar
	-->

<body class="navbar-fixed sidebar-nav fixed-nav">
<header class="navbar">
    <div class="container-fluid">
        <button class="navbar-toggler mobile-toggler hidden-lg-up" type="button">&#9776;</button>
        
        <ul class="nav navbar-nav hidden-md-down">
            <li class="nav-item">
                <a class="nav-link navbar-toggler layout-toggler" href="#">&#9776;</a>
            </li>

            <li class="nav-item p-x-1">
                <a class="nav-link" href="<?php echo e(route('default')); ?>">صفحه اصلی سایت</a>
            </li>
        </ul>
        <ul class="nav navbar-nav pull-left hidden-md-down">
            
            
            
            
            
            
            
            
            
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button"
                   aria-haspopup="true" aria-expanded="false">
                    
                    <span class="hidden-md-down"><?php echo e(Auth::user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                
                
                
                
                
                <!--<a class="dropdown-item" href="#"><i class="fa fa-usd"></i> Payments<span class="tag tag-default">42</span></a>-->
                    <div class="divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick=" event.preventDefault();
                       document.getElementById('logout-form').submit()" ;><i class="fa fa-lock"></i> خروج</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
            <li class="nav-item">
                
            </li>

        </ul>
    </div>
</header>
<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>"><i class="icon-speedometer"></i> داشبورد <span
                        class="tag tag-info">جدید</span></a>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-home"></i>صفحه اصلی</a>
                <ul class="nav-dropdown-items">

                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-frame"></i>هدر سایت</a>
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('headers.create')); ?>"><i class="icon-picture"></i>
                                    ایجاد
                                    هدر</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('headers.index')); ?>"><i class="icon-list"></i>لیست
                                    هدرها</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-frame"></i>اسلایدر</a>
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('slides.create')); ?>"><i class="icon-picture"></i>
                                    ایجاد
                                    اسلاید</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('slides.index')); ?>"><i class="icon-list"></i>لیست
                                    اسلایدها</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-people"></i>مدیریت مشتریان</a>
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('customers.create')); ?>"><i class="icon-people"></i>
                                    ایجاد
                                    مشتری</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('customers.index')); ?>"><i class="icon-list"></i>لیست
                                    مشتریان</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-people"></i>مدیریت خدمات</a>
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('services.create')); ?>"><i class="icon-people"></i>
                                    ایجاد
                                    خدمت</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('services.index')); ?>"><i class="icon-list"></i>لیست
                                    خدمات</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-people"></i>مدیریت شمارنده
                            ها</a>
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('counters.create')); ?>"><i class="icon-people"></i>
                                    ایجاد
                                    شمارنده</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('counters.index')); ?>"><i class="icon-list"></i>لیست
                                    شمارنده ها</a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-people"></i>مدیریت درباره ما
                        </a>
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('abouts.create')); ?>"><i class="icon-people"></i>
                                    ایجاد
                                    درباره ما</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('abouts.index')); ?>"><i class="icon-list"></i>
                                    لیست درباره ما</a>
                            </li>
                        </ul>
                    </li>

                </ul>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-people"></i>کاربران</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('users.create')); ?>"><i class="icon-user-follow"></i> ثبت
                            کاربر</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('users.index')); ?>"><i class="icon-people"></i> لیست
                            کاربران</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-globe-alt"></i>پروژه ها</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('projects.create')); ?>"><i class="icon-plus"></i>ایجاد
                            پروژه</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('projects.index')); ?>"><i class="icon-docs"></i>لیست پروژه ها</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-puzzle"></i>دسته بندی</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('categories.create')); ?>"><i class="icon-plus"></i>ایجاد دسته
                            بندی
                            جدید</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('categories.index')); ?>"><i class="icon-docs"></i>لیست دسته
                            بندی
                            ها</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-puzzle"></i>سوالات متداول</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('questions.create')); ?>"><i class="icon-plus"></i>ایجاد سوال
                            و پاسخ جدید</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('questions.index')); ?>"><i class="icon-docs"></i>لیست سوالات
                            متداول</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-puzzle"></i>پیام های دریافتی</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('messages.index')); ?>"><i class="icon-docs"></i>لیست پیام
                            ها</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-docs"></i>رسانه ها</a>
                <ul class="nav-dropdown-items">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('photos.index')); ?>"><i class="icon-list"></i>لیست فایل
                            ها</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('photos.create')); ?>"><i class="icon-plus"></i>آپلود فایل</a>
                    </li>
                </ul>
            </li>

        </ul>
    </nav>
</div>
<!-- Main content -->
<main class="main">

    <div class="container-fluid bg-content">
        <div class="animated fadeIn">

            <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

    </div>
    <!--/.container-fluid-->
</main>

<script src="<?php echo e(asset('js/all-admin.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\company\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>