<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_slide')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_slide')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_slide')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_slide')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_slide')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_slide')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست اسلاید ها</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th></th>
            <th>عنوان</th>
            <th>توضیحات</th>
            <th>وضعیت</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e($slide->photo ? $slide->photo->path : "http://www.placehold.it/400"); ?>"
                         class="img-fluid" width="80">
                </td>
                <td><a href="<?php echo e(route('slides.edit', $slide->id)); ?>"><?php echo e($slide->title); ?></a></td>
                <td><?php echo e(\Illuminate\Support\Str::limit($slide->description, 50)); ?></td>
                <?php if($slide->status == 0): ?>
                    <td><span class="tag tag-pill tag-danger">غیر فعال</span></td>
                <?php else: ?>
                    <td><span class="tag tag-pill tag-success">فعال</span></td>
                <?php endif; ?>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($slide->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($slides->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/slides/index.blade.php ENDPATH**/ ?>