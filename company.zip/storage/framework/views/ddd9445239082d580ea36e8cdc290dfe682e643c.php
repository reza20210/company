﻿

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->

    <!-- Page Title -->
    <div class="page-title-area" style="background-image: url(<?php echo e($about->third_photo->path); ?>); ">
        <div class="title-shape">
            <img src="<?php echo e(asset('assets/img/title/title-bg-shape.png')); ?>" alt="Shape">
        </div>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-content">
                        <h2>درباره ما</h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('default')); ?>">صفحه اصلی</a>
                            </li>
                            <li>
                                <i class='bx bx-chevron-left'></i>
                            </li>
                            <li>
                                <span>درباره ما</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- About -->
    <section class="about-area four section-overlay pt-100 pb-70">
        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-5">
                    <div class="about-img">
                        <div class="row align-items-end">
                            <div class="col-sm-6 col-lg-6">
                                <img
                                    src="<?php echo e($about->fifth_photo_id ? $about->fifth_photo->path : "http://www.placehold.it/900x300"); ?>"
                                    alt="About">
                            </div>
                            <div class="col-sm-6 col-lg-6">
                                <img
                                    src="<?php echo e($about->sixth_photo_id ? $about->sixth_photo->path : "http://www.placehold.it/900x300"); ?>"
                                    alt="About">
                            </div>
                        </div>
                        <div class="years">
                            <h3><?php echo e($counter->workExperience); ?>+ <br> <span>سال</span></h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-7">
                    <div class="about-content">
                        <div class="section-title">
                            <span class="sub-title">درباره ما</span>
                            <h2><?php echo e($about->title); ?><span> <?php echo e($counter->workExperience); ?>+</span> سال تجربه</h2>
                        </div>
                        <p class="about-p"><?php echo e($about->description); ?></p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- End About -->

    <!-- Counter -->
    <?php echo $__env->make('layouts.counters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Counter -->

    <!-- Team -->
    <section class="team-area four ptb-100">
        <div class="container">

            <div class="section-title">
                <span class="sub-title">اعضای تیم</span>
                <h2>ملاقات عالی با <span>تیم</span> به چه کسانی وابسته هستیم</h2>
            </div>

            <?php echo $__env->make('layouts.team_members', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="text-center">
                <a class="common-btn" href="<?php echo e(route('users')); ?>">
                    همه اعضا
                    <span></span>
                </a>
            </div>

        </div>
    </section>
    <!-- End Team -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/about.blade.php ENDPATH**/ ?>