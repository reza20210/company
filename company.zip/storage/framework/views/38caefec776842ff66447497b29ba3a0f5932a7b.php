<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_question')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_question')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_question')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_question')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_question')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_question')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست سوالات متداول</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>شناسه</th>
            <th>عنوان سوال</th>
            <th>پاسخ</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($question->id); ?></td>
                <td><a href="<?php echo e(route('questions.edit', $question->id)); ?>"><?php echo e($question->questionTitle); ?></a></td>
                <td><?php echo e(\Illuminate\Support\Str::limit($question->answer, 50)); ?></td>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($question->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($questions->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/questions/index.blade.php ENDPATH**/ ?>