<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-6 col-lg-4">
        <div class="services-item card-overlay active">
            <h3>
                <a href="<?php echo e(route('showService', $service->id)); ?>"><?php echo e($service->title); ?></a>
            </h3>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\company\resources\views/layouts/services.blade.php ENDPATH**/ ?>