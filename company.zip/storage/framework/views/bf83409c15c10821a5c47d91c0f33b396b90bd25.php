<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ایجاد کاربر جدید</h3>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::open(['action' => '\App\Http\Controllers\Admin\AdminUserController@store', 'files' => true]); ?>

            <div class="form-group">
                <?php echo e(Form::label('name', 'نام و نام خانوادگی: (اجباری)')); ?>

                <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('bio', 'بیوگرافی (رزومه - اجباری):')); ?>

                <?php echo e(Form::textarea('bio', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('email', 'ایمیل: (اجباری)')); ?>

                <?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('roles', 'نقش: (اجباری)')); ?>

                <?php echo e(Form::select('roles[]', $roles, null, ['multiple' => 'multiple','class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('status', 'وضعیت: (اجباری)')); ?>

                <?php echo e(Form::select('status', [1 => 'فعال' , 0 => 'غیرفعال'] ,0 , ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('password', 'رمز عبور: (اجباری)')); ?>

                <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('avatar', 'تصویر پروفایل: (اجباری)')); ?>

                <?php echo e(Form::file('avatar', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('ذخیره', ['class' => 'btn btn-success']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#bio').summernote({
                height: 300,                 // set editor height
                width: "90%",                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor
                dialogsInBody: true
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/users/create.blade.php ENDPATH**/ ?>