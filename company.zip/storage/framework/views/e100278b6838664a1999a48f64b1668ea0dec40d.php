<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_header')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_header')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_header')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_header')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_header')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_header')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست هدر ها</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>شناسه</th>
            <th>ایمیل</th>
            <th>شماره تلفن</th>
            <th>عنوان سایت</th>
            <th>آدرس شرکت</th>
            <th>توضیحات سایت</th>
            <th>لوگو سایت</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($header->id); ?></td>
                <td><a href="<?php echo e(route('headers.edit', $header->id)); ?>"><?php echo e($header->email); ?></a></td>
                <td><?php echo e($header->telephoneNumber); ?></td>
                <td><?php echo e($header->title); ?></td>
                <td><?php echo e(\Illuminate\Support\Str::limit($header->address, 50)); ?></td>
                <td><?php echo e(\Illuminate\Support\Str::limit($header->description, 50)); ?></td>
                <td>
                    <img
                        src="<?php echo e($header->siteLogoId ? $header->siteLogo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($header->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($headers->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/headers/index.blade.php ENDPATH**/ ?>