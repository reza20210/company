<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_about')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_about')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_about')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_about')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_about')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_about')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">درباره ما</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>عنوان</th>
            <th>توضیحات</th>
            <th>تصویر اول</th>
            <th>تصویر دوم</th>
            <th>تصویر سوم</th>
            <th>تصویر چهارم</th>
            <th>تصویر پنجم</th>
            <th>تصویر ششم</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('abouts.edit', $about->id)); ?>"><?php echo e($about->title); ?></a></td>
                <td><?php echo e(\Illuminate\Support\Str::limit($about->description, 50)); ?></td>
                <td>
                    <img
                        src="<?php echo e($about->first_photo_id ? $about->first_photo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td>
                    <img
                        src="<?php echo e($about->second_photo_id ? $about->second_photo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td>
                    <img
                        src="<?php echo e($about->third_photo_id ? $about->third_photo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td>
                    <img
                        src="<?php echo e($about->forth_photo_id ? $about->forth_photo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td>
                    <img
                        src="<?php echo e($about->fifth_photo_id ? $about->fifth_photo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td>
                    <img
                        src="<?php echo e($about->sixth_photo_id ? $about->sixth_photo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($about->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($abouts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/abouts/index.blade.php ENDPATH**/ ?>