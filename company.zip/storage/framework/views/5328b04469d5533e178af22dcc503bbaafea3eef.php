<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-6 col-lg-4">
        <div class="projects-item card-overlay">
            <img src="<?php echo e($project->photo ? $project->photo->path : "http://www.placehold.it/900x300"); ?>"
                 alt="Projects">
            <div class="inner">
                <h3>
                    <a href="<?php echo e(route('showProject', $project->id)); ?>"><?php echo e($project->category->title); ?></a>
                </h3>
                <span><?php echo e($project->title); ?></span>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\company\resources\views/layouts/projects.blade.php ENDPATH**/ ?>