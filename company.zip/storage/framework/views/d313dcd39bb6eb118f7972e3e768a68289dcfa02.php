<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ویرایش هدر</h3>
    <div class="row">
        <div class="col-md-3">
            <img src="<?php echo e($header->siteLogoId ? $header->siteLogo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
        </div>
        <div class="col-md-9">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::model($header ,['method' => 'PATCH' ,'action' => ['\App\Http\Controllers\Admin\AdminHeaderController@update', $header->id], 'files' => true]); ?>

            <div class="form-group">
                <?php echo e(Form::label('email', 'ایمیل: (اجباری)')); ?>

                <?php echo e(Form::text('email', $header->email, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('telephoneNumber', 'شماره تلفن: (اجباری)')); ?>

                <?php echo e(Form::text('telephoneNumber', $header->telephoneNumber, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('title', 'عنوان سایت: (اجباری)')); ?>

                <?php echo e(Form::text('title', $header->title, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('address', 'آدرس شرکت: (اجباری)')); ?>

                <?php echo e(Form::text('address', $header->address, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('description', 'توضیحات فوتر: (اجباری)')); ?>

                <?php echo e(Form::textarea('description', $header->description, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('siteLogoId', 'لوگو سایت:')); ?>

                <?php echo e(Form::file('siteLogoId', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('workTime', 'روزها و ساعات کاری: (اجباری)')); ?>

                <?php echo e(Form::text('workTime', $header->workTime, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('telegram', 'کانال تلگرام: (اجباری)')); ?>

                <?php echo e(Form::text('telegram', $header->telegram, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('instagram', 'صفحه اینستاگرام: (اجباری)')); ?>

                <?php echo e(Form::text('instagram', $header->instagram, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('youtube', 'کانال یوتیوب: (اجباری)')); ?>

                <?php echo e(Form::text('youtube', $header->youtube, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('twitter', 'صفحه توییتر: (اجباری)')); ?>

                <?php echo e(Form::text('twitter', $header->twitter, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('facebook', 'صفحه فیسبوک: (اجباری)')); ?>

                <?php echo e(Form::text('facebook', $header->facebook, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('بروزرسانی', ['class' => 'btn btn-success col-md-3']);; ?>

            </div>
            <?php echo Form::close(); ?>

            <?php echo Form::open(['method' => 'DELETE' ,'action' => ['\App\Http\Controllers\Admin\AdminHeaderController@destroy', $header->id]]); ?>

            <div class="form-group">
                <?php echo Form::submit('حذف', ['class' => 'btn btn-danger col-md-3']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#description').summernote({
                height: 300,                 // set editor height
                width: "90%",                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor
                dialogsInBody: true
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/headers/edit.blade.php ENDPATH**/ ?>