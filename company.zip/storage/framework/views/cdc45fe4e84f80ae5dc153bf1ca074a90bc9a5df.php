<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ویرایش درباره ما</h3>
    <div class="row">
        <div class="col-md-3">
            <img src="<?php echo e($about->first_photo_id ? $about->first_photo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
            <img src="<?php echo e($about->second_photo_id ? $about->second_photo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
            <img src="<?php echo e($about->third_photo_id ? $about->third_photo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
            <img src="<?php echo e($about->forth_photo_id ? $about->forth_photo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
            <img src="<?php echo e($about->fifth_photo_id ? $about->fifth_photo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
            <img src="<?php echo e($about->sixth_photo_id ? $about->sixth_photo->path : "http://www.placehold.it/400"); ?>"
                 class="img-fluid">
        </div>
        <div class="col-md-9">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::model($about ,['method' => 'PATCH' ,'action' => ['\App\Http\Controllers\Admin\AdminAboutController@update', $about->id], 'files' => true]); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'عنوان: (اجباری)')); ?>

                <?php echo e(Form::text('title', $about->title, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('description', 'توضیحات: (اجباری)')); ?>

                <?php echo e(Form::textarea('description', $about->description, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('first_photo_id', 'تصویر اول:')); ?>

                <?php echo e(Form::file('first_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('second_photo_id', 'تصویر دوم:')); ?>

                <?php echo e(Form::file('second_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('third_photo_id', 'تصویر سوم:')); ?>

                <?php echo e(Form::file('third_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('forth_photo_id', 'تصویر چهارم:')); ?>

                <?php echo e(Form::file('forth_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('fifth_photo_id', 'تصویر پنجم:')); ?>

                <?php echo e(Form::file('fifth_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('sixth_photo_id', 'تصویر ششم:')); ?>

                <?php echo e(Form::file('sixth_photo_id', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('بروزرسانی', ['class' => 'btn btn-success col-md-3']);; ?>

            </div>
            <?php echo Form::close(); ?>

            <?php echo Form::open(['method' => 'DELETE' ,'action' => ['\App\Http\Controllers\Admin\AdminAboutController@destroy', $about->id]]); ?>

            <div class="form-group">
                <?php echo Form::submit('حذف', ['class' => 'btn btn-danger col-md-3']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/abouts/edit.blade.php ENDPATH**/ ?>