﻿<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <!-- Box Icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/boxicons.min.css')); ?>">
    <!-- Mean Menu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.css')); ?>">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
    <!-- Flat Icon CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/flaticon.css')); ?>">
    <!-- Modal Video CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/modal-video.min.css')); ?>">
    <!-- Odometer CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/odometer.min.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <!-- RTL CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/rtl.css')); ?>">

    <title><?php echo e($header ? $header->title : ""); ?></title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
</head>
<body>

<!-- Preloader -->
<div class="loader">
    <div class="d-table">
        <div class="d-table-cell">
            <div class="pre-load">
                <div class="inner one"></div>
                <div class="inner two"></div>
                <div class="inner three"></div>
            </div>
        </div>
    </div>
</div>
<!-- End Preloader -->

<!-- Header -->
<div class="header-area">
    <div class="container">
        <div class="row">

            <div class="col-sm-9 col-lg-8">
                <div class="left">
                    <ul>
                        <li>
                            <i class='bx bx-mail-send'></i>
                            <a href="mailto:<?php echo e($header ? $header->email : ""); ?>"><?php echo e($header ? $header->email : ""); ?></a>
                        </li>
                        <li>
                            <i class='bx bx-phone-call'></i>
                            <a href="tel:<?php echo e($header ? $header->telephoneNumber : ""); ?>"><?php echo e($header ? $header->telephoneNumber : ""); ?></a>
                        </li>
                        <li>
                            <i class='bx bx-time'></i>
                            <span><?php echo e($header ? $header->workTime : ""); ?></span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-sm-3 col-lg-4">
                <div class="right">
                    <ul>
                        <li>
                            <a href="<?php echo e($header ? $header->telegram : ""); ?>" target="_blank">
                                <i class='bx bxl-telegram'></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($header ? $header->instagram : ""); ?>" target="_blank">
                                <i class='bx bxl-instagram'></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($header ? $header->youtube : ""); ?>" target="_blank">
                                <i class='bx bxl-youtube'></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($header ? $header->twitter : ""); ?>" target="_blank">
                                <i class='bx bxl-twitter'></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($header ? $header->facebook : ""); ?>" target="_blank">
                                <i class='bx bxl-facebook'></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- End Header -->

<!-- Navbar -->
<div class="navbar-area sticky-top">
    <!-- Menu For Mobile Device -->
    <div class="mobile-nav">
        <a href="<?php echo e(route('default')); ?>" class="logo">
            <img src="<?php echo e($header->siteLogoId ? $header->siteLogo->path : "http://www.placehold.it/900x300"); ?>"
                 alt="Logo">
        </a>
    </div>

    <!-- Menu For Desktop Device -->
    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="<?php echo e(route('default')); ?>">
                    <img src="<?php echo e($header->siteLogoId ? $header->siteLogo->path : "http://www.placehold.it/900x300"); ?>"
                         alt="Logo">
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="<?php echo e(route('default')); ?>" class="nav-link active">خانه </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link dropdown-toggle">صفحات <i class='bx bx-chevron-down'></i></a>
                            <ul class="dropdown-menu">
                                <li class="nav-item">
                                    <a href="#" class="nav-link dropdown-toggle">کاربران <i
                                            class='bx bx-chevron-down'></i></a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('login')); ?>" class="nav-link">ورود</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('register')); ?>" class="nav-link">ثبت نام</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link dropdown-toggle">تیم ما <i
                                            class='bx bx-chevron-down'></i></a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('users')); ?>" class="nav-link">تیم ما</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('testimonials')); ?>" class="nav-link">بازخورد مشتریان</a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('questions')); ?>" class="nav-link">سوالات متداول</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('about')); ?>" class="nav-link">درباره ما </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('services')); ?>" class="nav-link">خدمات ما </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('projects')); ?>" class="nav-link">پروژه ها </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('contact')); ?>" class="nav-link">تماس با ما</a>
                        </li>
                    </ul>

                    <?php echo $__env->make('layouts.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </nav>
        </div>
    </div>
</div>
<!-- End Navbar -->

<!-- Banner -->
<div class="banner-area">
    <div class="banner-slider owl-theme owl-carousel">
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="overlay-banner">
                <div class="banner-item"
                     style="background-image: url(<?php echo e($slide->photo->path); ?>); ">
                    <div class="d-table">
                        <div class="d-table-cell">
                            <div class="container">
                                <div class="banner-content">
                                    <h1><?php echo e($slide->title); ?></h1>
                                    <p><?php echo e($slide->description); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- End Banner -->

<!-- Logo -->
<div class="logo-area">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-3">
                <div class="logo-text">
                    <h3>شرکتی که به ما اعتماد می کند</h3>
                </div>
            </div>

            <div class="col-lg-9">
                <div class="logo-slider owl-theme owl-carousel">

                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="logo-item">
                            <img
                                src="<?php echo e($customer->companyLogoId ? $customer->companyLogo->path : "http://www.placehold.it/400"); ?>"
                                alt="Logo">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

        </div>
    </div>
</div>
<!-- End Logo -->

<!-- About -->
<section class="about-area section-overlay pt-100 pb-70">
    <div class="container-fluid">
        <div class="row align-items-center">

            <div class="col-lg-7">
                <div class="about-content">
                    <div class="section-title">
                        <span class="sub-title">درباره ما</span>
                        <h2><?php echo e($about->title); ?><span> <?php echo e($counter->workExperience); ?>+</span> سال تجربه کاری
                        </h2>
                    </div>
                    <p class="about-p"><?php echo e($about->description); ?></p>
                    <a class="common-btn" href="<?php echo e(route('about')); ?>">
                        درباره ما کاوش کنید
                        <span></span>
                    </a>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="about-img">
                    <div class="row align-items-end">
                        <div class="col-sm-6 col-lg-6">
                            <img
                                src="<?php echo e($about->first_photo_id ? $about->first_photo->path : "http://www.placehold.it/900x300"); ?>"
                                alt="About">
                        </div>
                        <div class="col-sm-6 col-lg-6">
                            <img
                                src="<?php echo e($about->second_photo_id ? $about->second_photo->path : "http://www.placehold.it/900x300"); ?>"
                                alt="About">
                        </div>
                        <div class="col-lg-12">
                            <img
                                src="<?php echo e($about->third_photo_id ? $about->third_photo->path : "http://www.placehold.it/900x300"); ?>"
                                alt="About">
                        </div>
                    </div>
                    <div class="years">
                        <h3><?php echo e($counter->workExperience); ?>+ <br> <span>سال</span></h3>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- End About -->

<!-- Services -->
<section class="services-area pt-100 pb-70">
    <div class="container">

        <div class="section-title">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <span class="sub-title">خدمات ما</span>
                    <h2><span>خدماتی</span> که ما برای مشتریان نهایی خود فراهم می کنیم</h2>
                </div>
            </div>
        </div>

        <div class="row">

            <?php echo $__env->make('layouts.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>
</section>
<!-- End Services -->

<!-- Projects -->
<section class="projects-area section-overlay pt-100 pb-70">
    <div class="container">

        <div class="section-title">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <span class="sub-title">پروژه ها</span>
                    <h2>تعدادی از <span>پروژه ها</span> جایی که به موفقیت بزرگی دست می یابیم</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <?php echo $__env->make('layouts.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>
</section>
<!-- End Projects -->

<!-- Counter -->
<?php echo $__env->make('layouts.counters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Counter -->

<!-- Team -->
<section class="team-area ptb-100">
    <div class="container">

        <div class="section-title">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <span class="sub-title">اعضای تیم</span>
                    <h2>ملاقات عالی با <span>تیم</span> به چه کسانی وابسته هستیم</h2>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.team_members', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="text-center">
            <a class="common-btn" href="<?php echo e(route('users')); ?>">
                همه اعضا
                <span></span>
            </a>
        </div>

    </div>
</section>
<!-- End Team -->

<!-- Testimonials -->
<section class="testimonials-area ptb-100">
    <div class="container">

        <div class="section-title">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <span class="sub-title">بازخورد مشتریان</span>
                    <h2>مشتریان ما در مورد <span><?php echo e($header->title); ?></span> چه می گویند</h2>
                </div>
            </div>
        </div>

        <div class="testimonials-slider owl-theme owl-carousel">

            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="testimonials-item">
                    <i class='bx bxs-quote-right icon'></i>
                    <p><?php echo e($customer->companyAgentComment); ?></p>
                    <img
                        src="<?php echo e($customer->companyAgentPhotoId ? $customer->companyAgentPhoto->path : "http://www.placehold.it/400"); ?>"
                        alt="Testimonials">
                    <h3><?php echo e($customer->companyAgentName); ?></h3>
                    <span><?php echo e($customer->companyAgentRole); ?></span>
                    <ul>
                        <li>
                            <i class='bx bxs-star checked'></i>
                        </li>
                        <li>
                            <i class='bx bxs-star checked'></i>
                        </li>
                        <li>
                            <i class='bx bxs-star checked'></i>
                        </li>
                        <li>
                            <i class='bx bxs-star checked'></i>
                        </li>
                        <li>
                            <i class='bx bxs-star checked'></i>
                        </li>
                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section>
<!-- End Testimonials -->

<!-- Footer -->
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Footer -->

<!-- Go Top -->
<div class="go-top">
    <i class="bx bxs-up-arrow-alt"></i>
    <i class="bx bxs-up-arrow-alt"></i>
</div>
<!-- End Go Top -->

<!-- Essential JS -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- Form Validator JS -->
<script src="<?php echo e(asset('assets/js/form-validator.min.js')); ?>"></script>
<!-- Contact JS -->
<script src="<?php echo e(asset('assets/js/contact-form-script.js')); ?>"></script>
<!-- Ajax Chip JS -->
<script src="<?php echo e(asset('assets/js/jquery.ajaxchimp.min.js')); ?>"></script>
<!-- Mean Menu JS -->
<script src="<?php echo e(asset('assets/js/jquery.meanmenu.js')); ?>"></script>
<!-- Wow JS -->
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<!-- Owl Carousel JS -->
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
<!-- Modal Video JS -->
<script src="<?php echo e(asset('assets/js/jquery-modal-video.min.js')); ?>"></script>
<!-- Odometer JS -->
<script src="<?php echo e(asset('assets/js/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.appear.min.js')); ?>"></script>
<!-- Smooth Scroll JS -->
<script src="<?php echo e(asset('assets/js/smoothscroll.min.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/index.blade.php ENDPATH**/ ?>