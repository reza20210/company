<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_message')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_message')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست پیام ها</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>نام</th>
            <th>ایمیل</th>
            <th>شماره تلفن</th>
            <th>موضوع</th>
            <th>متن پیغام</th>
            <th>تاریخ دریافت</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('messages.show', $message->id)); ?>"><?php echo e($message->name); ?></a></td>
                <td><?php echo e($message->email); ?></td>
                <td><?php echo e($message->telephone); ?></td>
                <td><?php echo Str::limit($message->subject, 20); ?></td>
                <td><?php echo Str::limit($message->message, 50); ?></td>
                <td><?php echo e(Verta::instance($message->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($messages->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>