<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_counter')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_counter')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_counter')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_counter')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_counter')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_counter')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست شمارنده ها</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>شناسه</th>
            <th>سال تجربه کاری</th>
            <th>مشتریان راضی</th>
            <th>محصول موفق</th>
            <th>ساعت کاری</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($counter->id); ?></td>
                <td><a href="<?php echo e(route('counters.edit', $counter->id)); ?>"><?php echo e($counter->workExperience); ?></a></td>
                <td><?php echo e($counter->satisfiedCustomers); ?></td>
                <td><?php echo e($counter->successfulProduct); ?></td>
                <td><?php echo e($counter->hoursOfWork); ?></td>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($counter->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($counters->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/counters/index.blade.php ENDPATH**/ ?>