<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_category')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_category')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_category')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_category')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_category')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_category')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست دسته بندی ها</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>شناسه</th>
            <th>عنوان</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><a href="<?php echo e(route('categories.edit', $category->id)); ?>"><?php echo e($category->title); ?></a></td>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($category->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>