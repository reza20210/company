<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_service')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_service')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_service')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_service')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_service')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_service')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست خدمات</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>شناسه</th>
            <th>عنوان</th>
            <th>توضیحات</th>
            <th>تصاویر</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($service->id); ?></td>
                <td><a href="<?php echo e(route('services.edit', $service->id)); ?>"><?php echo e($service->title); ?></a></td>
                <td><?php echo Str::limit($service->description, 50); ?></td>
                <td>
                    <?php $__currentLoopData = $service->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($photo ? $photo->path : "http://www.placehold.it/400"); ?>"
                             class="img-fluid" width="80">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td><?php echo e(Verta::instance($service->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($services->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/services/index.blade.php ENDPATH**/ ?>