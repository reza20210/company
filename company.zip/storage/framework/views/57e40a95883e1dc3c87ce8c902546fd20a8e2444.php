<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ایجاد شمارنده های جدید</h3>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::open(['action' => '\App\Http\Controllers\Admin\AdminCounterController@store']); ?>

            <div class="form-group">
                <?php echo e(Form::label('workExperience', 'سال تجربه کاری: (اجباری)')); ?>

                <?php echo e(Form::text('workExperience', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('satisfiedCustomers', 'مشتریان راضی: (اجباری)')); ?>

                <?php echo e(Form::text('satisfiedCustomers', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('successfulProduct', 'محصول موفق: (اجباری)')); ?>

                <?php echo e(Form::text('successfulProduct', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('hoursOfWork', 'ساعت کاری: (اجباری)')); ?>

                <?php echo e(Form::text('hoursOfWork', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('ذخیره', ['class' => 'btn btn-success']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/counters/create.blade.php ENDPATH**/ ?>