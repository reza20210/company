<div class="side-nav">
    <div class="nav-search">
        <i id="search-btn" class="bx bx-search-alt"></i>
        <div id="search-overlay" class="block">
            <div class="centered">
                <div id="search-box">
                    <i id="close-btn" class="bx bx-x"></i>
                    <?php echo Form::open(['method' => 'GET','action' => 'App\Http\Controllers\Frontend\MainController@searchProject']); ?>

                    <input name="title" type="text" class="form-control" placeholder="جستجو..."/>
                    <button type="submit" class="btn">جستجو</button>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\company\resources\views/layouts/search.blade.php ENDPATH**/ ?>