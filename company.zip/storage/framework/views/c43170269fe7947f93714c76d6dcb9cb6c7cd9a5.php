<?php $__env->startSection('content'); ?>
    <?php if(Session::has('delete_customer')): ?>
        <div class="alert alert-danger">
            <div><?php echo e(session('delete_customer')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('add_customer')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('add_customer')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(Session::has('update_customer')): ?>
        <div class="alert alert-success">
            <div><?php echo e(session('update_customer')); ?></div>
        </div>
    <?php endif; ?>
    <h3 class="p-b-2">لیست مشتریان</h3>
    <table class="table table-hover bg-content">
        <thead>
        <tr>
            <th>لوگوی شرکت</th>
            <th>عکس نماینده شرکت</th>
            <th>نام شرکت</th>
            <th>نام نماینده شرکت</th>
            <th>مسئولیت (نقش) نماینده شرکت</th>
            <th>ایمیل شرکت</th>
            <th>ایمیل نماینده شرکت</th>
            <th>توضیحات نماینده شرکت</th>
            <th>تاریخ ایجاد</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img
                        src="<?php echo e($customer->companyLogoId ? $customer->companyLogo->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td>
                    <img
                        src="<?php echo e($customer->companyAgentPhotoId ? $customer->companyAgentPhoto->path : "http://www.placehold.it/400"); ?>"
                        class="img-fluid" width="80">
                </td>
                <td><a href="<?php echo e(route('customers.edit', $customer->id)); ?>"><?php echo e($customer->companyTitle); ?></a></td>
                <td><?php echo e($customer->companyAgentName); ?></td>
                <td><?php echo e($customer->companyAgentRole); ?></td>
                <td><?php echo e($customer->companyEmail); ?></td>
                <td><?php echo e($customer->companyAgentEmail); ?></td>
                <td><?php echo e(\Illuminate\Support\Str::limit($customer->companyAgentComment, 50)); ?></td>
                <td><?php echo e(\Hekmatinasser\Verta\Verta::instance($customer->created_at)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="col-md-12 text-md-center">
        <?php echo e($customers->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>