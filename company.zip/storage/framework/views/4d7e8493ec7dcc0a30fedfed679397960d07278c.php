<div class="row">

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-lg-4">
            <div class="team-item">
                <div class="top card-overlay">
                    <img
                        src="<?php echo e($user->photo ? $user->photo->path : "http://www.placehold.it/900x300"); ?>"
                        alt="Team">
                </div>
                <div class="bottom">
                    <ul>
                        <li>
                        </li>
                        <li>
                        </li>
                        <li>
                        </li>
                    </ul>
                    <h3>
                        <a href="<?php echo e(route('user', $user->id)); ?>"><?php echo e($user->name); ?></a>
                    </h3>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\company\resources\views/layouts/team_members.blade.php ENDPATH**/ ?>