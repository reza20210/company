<!-- Navbar -->
<div class="navbar-area sticky-top">
    <!-- Menu For Mobile Device -->
    <div class="mobile-nav">
        <a href="<?php echo e(route('default')); ?>" class="logo">
            <img src="<?php echo e($header->siteLogoId ? $header->siteLogo->path : "http://www.placehold.it/900x300"); ?>"
                 alt="Logo">
        </a>
    </div>

    <!-- Menu For Desktop Device -->
    <div class="main-nav four">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="<?php echo e(route('default')); ?>">
                    <img
                        src="<?php echo e($header->siteLogoId ? $header->siteLogo->path : "http://www.placehold.it/900x300"); ?>"
                        alt="Logo">
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="<?php echo e(route('default')); ?>" class="nav-link active">خانه </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link dropdown-toggle">صفحات <i
                                    class='bx bx-chevron-down'></i></a>
                            <ul class="dropdown-menu">
                                <li class="nav-item">
                                    <a href="#" class="nav-link dropdown-toggle">کاربران <i
                                            class='bx bx-chevron-down'></i></a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('login')); ?>" class="nav-link">ورود</a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('register')); ?>" class="nav-link">ثبت نام</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="#" class="nav-link dropdown-toggle">تیم ما <i
                                            class='bx bx-chevron-down'></i></a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('users')); ?>" class="nav-link">تیم ما</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('testimonials')); ?>" class="nav-link">بازخورد مشتریان</a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('questions')); ?>" class="nav-link">سوالات متداول</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('about')); ?>" class="nav-link">درباره ما </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('services')); ?>" class="nav-link">خدمات ما </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('projects')); ?>" class="nav-link">پروژه ها </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('contact')); ?>" class="nav-link">تماس با ما</a>
                        </li>
                    </ul>

                    <?php echo $__env->make('layouts.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </nav>
        </div>
    </div>
</div>
<!-- End Navbar -->
<?php /**PATH C:\xampp\htdocs\company\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>