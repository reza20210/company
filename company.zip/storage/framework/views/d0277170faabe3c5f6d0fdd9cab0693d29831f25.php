﻿

<?php $__env->startSection('content'); ?>
    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navbar -->

    <!-- Page Title -->
    <div class="page-title-area" style="background-image: url(<?php echo e($about->third_photo->path); ?>); ">
        <div class="title-shape">
            <img src="<?php echo e(asset('assets/img/title/title-bg-shape.png')); ?>" alt="Shape">
        </div>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-content">
                        <h2>سوالات متداول</h2>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('default')); ?>">صفحه اصلی</a>
                            </li>
                            <li>
                                <i class='bx bx-chevron-left'></i>
                            </li>
                            <li>
                                <span>سوالات متداول</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- FAQ -->
    <div class="faq-area pt-100 pb-70">
        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-6">
                    <div class="faq-img">
                        <img src="<?php echo e(asset('assets/img/faq-main1.jpg')); ?>" alt="FAQ">
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="faq-item">
                        <ul class="accordion">
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a><?php echo e($question->questionTitle); ?></a>
                                    <p><?php echo e($question->answer); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End FAQ -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/questions.blade.php ENDPATH**/ ?>