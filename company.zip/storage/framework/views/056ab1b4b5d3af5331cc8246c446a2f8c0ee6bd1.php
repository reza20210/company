<?php $__env->startSection('content'); ?>
    <h3 class="p-b-2 text-center">ایجاد مشتری جدید</h3>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <?php echo $__env->make('partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::open(['action' => '\App\Http\Controllers\Admin\AdminCustomerController@store', 'files' => true]); ?>

            <div class="form-group">
                <?php echo e(Form::label('companyEmail', 'ایمیل شرکت: (اجباری)')); ?>

                <?php echo e(Form::text('companyEmail', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyTitle', 'عنوان (نام) شرکت: (اجباری)')); ?>

                <?php echo e(Form::text('companyTitle', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyLogoId', 'لوگوی شرکت: (اجباری)')); ?>

                <?php echo e(Form::file('companyLogoId', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyAgentName', 'نام نماینده شرکت: (اجباری)')); ?>

                <?php echo e(Form::text('companyAgentName', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyAgentRole', 'نقش نماینده شرکت: (اجباری)')); ?>

                <?php echo e(Form::text('companyAgentRole', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyAgentEmail', 'ایمیل نماینده شرکت: (اجباری)')); ?>

                <?php echo e(Form::text('companyAgentEmail', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyAgentPhotoId', 'عکس نماینده شرکت: (اجباری)')); ?>

                <?php echo e(Form::file('companyAgentPhotoId', null,['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('companyAgentComment', 'توضیحات نماینده شرکت: (اجباری)')); ?>

                <?php echo e(Form::textarea('companyAgentComment', null, ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('ذخیره', ['class' => 'btn btn-success']);; ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\resources\views/admin/customers/create.blade.php ENDPATH**/ ?>