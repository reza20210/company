﻿@extends('layouts.master')

@section('content')
    <!-- Navbar -->
    @include('layouts.navbar')
    <!-- End Navbar -->

    <!-- Page Title -->
    <div class="page-title-area title-bg-three">
        <div class="title-shape">
            <img src="{{ asset('assets/img/title/title-bg-shape.png') }}" alt="Shape">
        </div>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-content">
                        <h2>پروژه ها</h2>
                        <ul>
                            <li>
                                <a href="{{ route('default') }}">صفحه اصلی</a>
                            </li>
                            <li>
                                <i class='bx bx-chevron-left'></i>
                            </li>
                            <li>
                                <span>پروژه ها</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Project Details -->
    <div class="project-details-area pt-100">
        <div class="container">

            <div class="details-img">
                <div class="row align-items-center">

                    <div class="col-lg-6">
                        <div class="img-left">
                            <img src="{{ $project->photo ? $project->photo->path : "http://www.placehold.it/900x300" }}"
                                 alt="Details">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="content-right">
                            <ul>
                                <li>
                                    دسته بندی:
                                    <span>{{ $project->category->title }}</span>
                                </li>
                                <li>
                                    کاربر:
                                    <span>{{ $project->user->name }}</span>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>

            <div class="details-handle">
                <h2>{{ $project->title }}</h2>
                <p>{!! $project->description !!}</p>
            </div>

        </div>
    </div>
    <!-- End Project Details -->
@endsection
